package bond.trader.ejb;

import java.util.List;

import javax.ejb.Local;
import javax.ejb.Remote;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import bond.trader.jpa.Ebonddata;


/**
 * Session Bean implementation class TraderBean
 */
@Stateless
@Local(TraderBeanLocal.class)
@Remote(TraderBeanRemote.class)
public class TraderBean implements TraderBeanRemote, TraderBeanLocal {

	@PersistenceContext(name="BondTraderJPA-PU")
    private EntityManager em1;
	
	/**
     * Default constructor. 
     */
    public TraderBean() {
        // TODO Auto-generated constructor stub
    }

	@Override
	public List<Ebonddata> viewAllbonds() {
		// TODO Auto-generated method stub
		String sql1 = "SELECT p FROM Ebonddata AS p";
        System.out.println(sql1);
        TypedQuery<Ebonddata> query1 = em1.createQuery(sql1, Ebonddata.class);

        // Execute the query, and get a collection of products back.
        List<Ebonddata> lb1 =  query1.getResultList();
        
//        String s1="";
//        
//        for(Ebonddata l1:lb1){
//        	s1+=l1.getIdlistbond()+"\t";
//        	s1+=l1.getBondname()+"\n";
//        }
//        
//        
//        s1+="Echo";
//        
//		
		return lb1;
	}
	
	public List<Ebonddata> viewSpecificbonds(String in) {
		// TODO Auto-generated method stub
		
//		StringBuilder builder = new StringBuilder();
		String sql2 = "SELECT p FROM Ebonddata AS p where p.currency= \'" + in + "\'";
		
//		String sql2 = "SELECT p FROM Ebonddata AS p where p.currency="+ (String)in;
        System.out.println(sql2);
        TypedQuery<Ebonddata> query2 = em1.createQuery(sql2, Ebonddata.class);

        // Execute the query, and get a collection of products back.
        List<Ebonddata> lb2 =  query2.getResultList();
        
//        String s1="";
//        
//        for(Ebonddata l1:lb1){
//        	s1+=l1.getIdlistbond()+"\t";
//        	s1+=l1.getBondname()+"\n";
//        }
//        
//        
//        s1+="Echo";
//        
//		
		return lb2;
	}
	
}
