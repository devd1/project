package bond.trader.jpa;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the listbond database table.
 * 
 */
@Entity
//@NamedQuery(name="Listbond.findAll", query="SELECT l FROM Listbond l")
@Table(name = "LISTBOND")
public class Listbond implements Serializable {
	private static final long serialVersionUID = 1L;

	
	private int idlistbond;

	private String bondname;

	public Listbond() {
	}
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public int getIdlistbond() {
		return this.idlistbond;
	}

	public void setIdlistbond(int idlistbond) {
		this.idlistbond = idlistbond;
	}

	public String getBondname() {
		return this.bondname;
	}

	public void setBondname(String bondname) {
		this.bondname = bondname;
	}

}