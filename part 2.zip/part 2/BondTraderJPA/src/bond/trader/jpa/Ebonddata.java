package bond.trader.jpa;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;


/**
 * The persistent class for the ebonddata database table.
 * 
 */
@Entity
@NamedQuery(name="Ebonddata.findAll", query="SELECT e FROM Ebonddata e")
public class Ebonddata implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private int id;

	private BigDecimal change;

	@Column(name="`Coupon Period`")
	private String coupon_Period;

	@Column(name="`Coupon%`")
	private BigDecimal coupon_;

	@Column(name="`Credit Rating`")
	private String credit_Rating;

	private String currency;

	@Column(name="`Face Value`")
	private BigDecimal face_Value;

	private BigDecimal high;

	private String isin;

	private String issueDate;

	private String issuerName;

	private BigDecimal last;

	private BigDecimal low;

	private String maturity;

	private String organization;

	private String sector;

	@Column(name="`Settlement Date`")
	private String settlement_Date;

	@Column(name="`Yield%`")
	private BigDecimal yield_;

	public Ebonddata() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public BigDecimal getChange() {
		return this.change;
	}

	public void setChange(BigDecimal change) {
		this.change = change;
	}

	public String getCoupon_Period() {
		return this.coupon_Period;
	}

	public void setCoupon_Period(String coupon_Period) {
		this.coupon_Period = coupon_Period;
	}

	public BigDecimal getCoupon_() {
		return this.coupon_;
	}

	public void setCoupon_(BigDecimal coupon_) {
		this.coupon_ = coupon_;
	}

	public String getCredit_Rating() {
		return this.credit_Rating;
	}

	public void setCredit_Rating(String credit_Rating) {
		this.credit_Rating = credit_Rating;
	}

	public String getCurrency() {
		return this.currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public BigDecimal getFace_Value() {
		return this.face_Value;
	}

	public void setFace_Value(BigDecimal face_Value) {
		this.face_Value = face_Value;
	}

	public BigDecimal getHigh() {
		return this.high;
	}

	public void setHigh(BigDecimal high) {
		this.high = high;
	}

	public String getIsin() {
		return this.isin;
	}

	public void setIsin(String isin) {
		this.isin = isin;
	}

	public String getIssueDate() {
		return this.issueDate;
	}

	public void setIssueDate(String issueDate) {
		this.issueDate = issueDate;
	}

	public String getIssuerName() {
		return this.issuerName;
	}

	public void setIssuerName(String issuerName) {
		this.issuerName = issuerName;
	}

	public BigDecimal getLast() {
		return this.last;
	}

	public void setLast(BigDecimal last) {
		this.last = last;
	}

	public BigDecimal getLow() {
		return this.low;
	}

	public void setLow(BigDecimal low) {
		this.low = low;
	}

	public String getMaturity() {
		return this.maturity;
	}

	public void setMaturity(String maturity) {
		this.maturity = maturity;
	}

	public String getOrganization() {
		return this.organization;
	}

	public void setOrganization(String organization) {
		this.organization = organization;
	}

	public String getSector() {
		return this.sector;
	}

	public void setSector(String sector) {
		this.sector = sector;
	}

	public String getSettlement_Date() {
		return this.settlement_Date;
	}

	public void setSettlement_Date(String settlement_Date) {
		this.settlement_Date = settlement_Date;
	}

	public BigDecimal getYield_() {
		return this.yield_;
	}

	public void setYield_(BigDecimal yield_) {
		this.yield_ = yield_;
	}

}