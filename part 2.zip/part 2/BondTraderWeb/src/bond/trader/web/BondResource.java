package bond.trader.web;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

import sun.applet.Main;

@Path("/bond007")
public class BondResource {
	
	
	public static int testInt=5;
    public static List<String> newList = new ArrayList<String>();
    
    static {
    	newList = new ArrayList<String>();
    	newList.add("ganesha");
    	newList.add("mayooreshwar");
    }
    
	@GET
	@Produces("text/plain")
	public int getTestInt() {
    	System.out.println("Received a GET request for persons");
    	return testInt;
	}

	@POST
    @Consumes("text/plain")
    public void postTestInt(String content) {
    	System.out.println("PersonResource received a POST request");
    	//newList.add(content);
    }
    
	@PUT
    @Consumes("text/plain")
    public void putTestInt(int content) {
    	System.out.println("PersonResource received a PUT request");
//    	newList.add(content);
    	testInt = content;
    }

}
