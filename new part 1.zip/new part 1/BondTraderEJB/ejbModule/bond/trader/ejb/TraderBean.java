package bond.trader.ejb;

import java.util.List;

import javax.ejb.Local;
import javax.ejb.Remote;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import bond.trader.jpa.Listbond;

/**
 * Session Bean implementation class TraderBean
 */
@Stateless
@Local(TraderBeanLocal.class)
@Remote(TraderBeanRemote.class)
public class TraderBean implements TraderBeanRemote, TraderBeanLocal {

	@PersistenceContext(name="BondTraderJPA-PU")
    private EntityManager em;
	
	
	/**
     * Default constructor. 
     */
    public TraderBean() {
        // TODO Auto-generated constructor stub
    }


	@Override
	public void addBond() {
		// TODO Auto-generated method stub
		System.out.println("TraderBeanaddbond1");
		Listbond l1 = new Listbond();
		l1.setBondname("devd");
		System.out.println("TraderBeanaddbond2");
		em.persist(l1);
		System.out.println("TraderBeanaddbond3");
		System.out.println("just added bond" +l1);
		
		
	}


	@Override
	public String testBondlist() {
		// TODO Auto-generated method stub
		System.out.println("TraderBeantestbond1");
		String sql = "SELECT p FROM Listbond AS p";
        System.out.println(sql);
        TypedQuery<Listbond> query = em.createQuery(sql, Listbond.class);
        System.out.println("TraderBeantestbond2");

        // Execute the query, and get a collection of products back.
        List<Listbond> lb1 =  query.getResultList();
        
        String s="";
        
        for(Listbond l:lb1){
        	s+=l.getIdlistbond()+"\t";
        	s+=l.getBondname()+"\n";
        }
        
        
        System.out.println("TraderBeantestbond3");
        s+="Echo";

		return s;
	}

}
