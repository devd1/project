package bond.trader.ejb;

import javax.ejb.Remote;

@Remote
public interface TraderBeanRemote {
	
	void addBond();
	String testBondlist();

}
