package bond.trader.ejb;

import javax.ejb.Local;

@Local
public interface TraderBeanLocal {
	
	void addBond();
	String testBondlist();

}
