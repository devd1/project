package bond.trader.jpa;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the ebonddata database table.
 * 
 */
@Entity
//@NamedQuery(name="Ebonddata.findAll", query="SELECT e FROM Ebonddata e")
@Table(name="ebonddata")
public class Ebonddata implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private int id;

	@Column(name="`Coupon Period`")
	private String coupon_Period;

	private BigDecimal couponPercent;

	private String creditRating;

	private String currency;

	@Column(name="`Face Value`")
	private BigDecimal face_Value;

	private BigDecimal high;

	private String isin;

	@Temporal(TemporalType.DATE)
	private Date issueDate;

	private String issuerName;

	private BigDecimal last;

	private BigDecimal low;

	private String maturity;

	private String organization;

	private BigDecimal priceChange;

	private String sector;

	@Temporal(TemporalType.DATE)
	@Column(name="`Settlement Date`")
	private Date settlement_Date;

	@Column(name="`Yield%`")
	private BigDecimal yield_;

	public Ebonddata() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCoupon_Period() {
		return this.coupon_Period;
	}

	public void setCoupon_Period(String coupon_Period) {
		this.coupon_Period = coupon_Period;
	}

	public BigDecimal getCouponPercent() {
		return this.couponPercent;
	}

	public void setCouponPercent(BigDecimal couponPercent) {
		this.couponPercent = couponPercent;
	}

	public String getCreditRating() {
		return this.creditRating;
	}

	public void setCreditRating(String creditRating) {
		this.creditRating = creditRating;
	}

	public String getCurrency() {
		return this.currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public BigDecimal getFace_Value() {
		return this.face_Value;
	}

	public void setFace_Value(BigDecimal face_Value) {
		this.face_Value = face_Value;
	}

	public BigDecimal getHigh() {
		return this.high;
	}

	public void setHigh(BigDecimal high) {
		this.high = high;
	}

	public String getIsin() {
		return this.isin;
	}

	public void setIsin(String isin) {
		this.isin = isin;
	}

	public Date getIssueDate() {
		return this.issueDate;
	}

	public void setIssueDate(Date issueDate) {
		this.issueDate = issueDate;
	}

	public String getIssuerName() {
		return this.issuerName;
	}

	public void setIssuerName(String issuerName) {
		this.issuerName = issuerName;
	}

	public BigDecimal getLast() {
		return this.last;
	}

	public void setLast(BigDecimal last) {
		this.last = last;
	}

	public BigDecimal getLow() {
		return this.low;
	}

	public void setLow(BigDecimal low) {
		this.low = low;
	}

	public String getMaturity() {
		return this.maturity;
	}

	public void setMaturity(String maturity) {
		this.maturity = maturity;
	}

	public String getOrganization() {
		return this.organization;
	}

	public void setOrganization(String organization) {
		this.organization = organization;
	}

	public BigDecimal getPriceChange() {
		return this.priceChange;
	}

	public void setPriceChange(BigDecimal priceChange) {
		this.priceChange = priceChange;
	}

	public String getSector() {
		return this.sector;
	}

	public void setSector(String sector) {
		this.sector = sector;
	}

	public Date getSettlement_Date() {
		return this.settlement_Date;
	}

	public void setSettlement_Date(Date settlement_Date) {
		this.settlement_Date = settlement_Date;
	}

	public BigDecimal getYield_() {
		return this.yield_;
	}

	public void setYield_(BigDecimal yield_) {
		this.yield_ = yield_;
	}

}